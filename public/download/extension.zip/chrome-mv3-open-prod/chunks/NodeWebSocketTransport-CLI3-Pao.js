import{g as a,p as i}from"./sidepanel-s21HF9kC.js";import"./_plugin-vue_export-helper-DZuXZARv.js";var l=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")};const c=a(l);/**
 * @license
 * Copyright 2018 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class o{static create(e,s){return new Promise((r,n)=>{const t=new c(e,[],{followRedirects:!0,perMessageDeflate:!1,allowSynchronousEvents:!1,maxPayload:268435456,headers:{"User-Agent":`Puppeteer ${i}`,...s}});t.addEventListener("open",()=>r(new o(t))),t.addEventListener("error",n)})}#e;onmessage;onclose;constructor(e){this.#e=e,this.#e.addEventListener("message",s=>{this.onmessage&&this.onmessage.call(null,s.data)}),this.#e.addEventListener("close",()=>{this.onclose&&this.onclose.call(null)}),this.#e.addEventListener("error",()=>{})}send(e){this.#e.send(e)}close(){this.#e.close()}}export{o as NodeWebSocketTransport};
